package com.example.staff.Service;

import java.util.List;

import com.example.staff.dto.Staffdto;
import com.example.staff.model.Staff;


public interface StaffService {
	List<Staffdto> getAllStaffs();
	Staffdto createStaff(Staff staff);
	Staffdto updateStaff(Long id,Staff staffdetails);
	void deleteStaff(Long id);
	
}
