package com.example.staff.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.staff.Service.StaffService;
import com.example.staff.dto.Staffdto;
import com.example.staff.exception.ResourceNotFoundException;
import com.example.staff.model.Staff;


@RestController
@RequestMapping("/hms/v2/")
public class StaffController {

	@Autowired
	StaffService staffservice;
	@GetMapping("/staff")
	public List<Staffdto> getAllstaff()
	{
	return staffservice.getAllStaffs();
	}
	@PostMapping("/staff")
	public ResponseEntity<String> createStaff(@RequestBody @Valid Staff staff)
	{
		staffservice.createStaff(staff);
		return ResponseEntity.ok("Staff details added successfully");
	}
	
	@PutMapping("/staff/{id}")
	public ResponseEntity<String> updatestaff(@PathVariable Long id, @Valid @RequestBody Staff staffdetails)throws ResourceNotFoundException
	{
		
		
	

		 staffservice.updateStaff(id, staffdetails);
		return ResponseEntity.ok("Staff details updated successfully");
		
	}
	@DeleteMapping("/staff/{id}")
	public ResponseEntity<Map<String, Boolean>> deletestaff(@PathVariable Long id) {
		staffservice.deleteStaff(id);
		Map<String, Boolean> response = new HashMap<>();
		response.put("deleted", Boolean.TRUE);
		return ResponseEntity.ok(response);
	}

	
	
}
