package com.example.reservation.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.reservation.DTO.ReservationDTO;
import com.example.reservation.Service.ReservationService;


import com.example.reservation.model.Reservation;


@RestController
@RequestMapping("/hms/v4/")
public class ReservationController {

	@Autowired
	ReservationService reservationService;
	
	
	 
	@GetMapping("/reserve")
	public List<ReservationDTO> getAllreservations()
	{
	 return reservationService.getAllreservations();
	}
	
	@PostMapping("/reserve")
	public ResponseEntity<String>  createreservation(@RequestBody @Valid Reservation reservation)
	{
		 reservationService.createreservation(reservation);
		 return ResponseEntity.ok("Reservation added successfully.");
		 
	}
	
	@PutMapping("/reserve/{id}")
	public ResponseEntity<String> updatereservation(@PathVariable Long id,@Valid @RequestBody Reservation reservationdetails)
	{
		
		 reservationService.updatereservation(id, reservationdetails);
		 
	        return ResponseEntity.ok("Reservation updated successfully.");
		
	}
	@DeleteMapping("/reserve/{id}")
	public ResponseEntity<Map<String, Boolean>> deletereservation(@PathVariable Long id)  {
	         reservationService.deletereservation(id);
		Map<String, Boolean> response = new HashMap<>();
		response.put("deleted", Boolean.TRUE);
		return ResponseEntity.ok(response);
	}

	
	
}
