package com.example.payment.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;



import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
@Entity
@Table(name="payment")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Payment {


	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	 long id;
	@Column(name="card_holder_name")
	 String card_holder_name;
	@Column(name="card_number")
	 long card_number;
	@Column(name="exp_date")
	 String exp_date;
	@Column(name="amount")
	 long amount;
	@Column(name="pay_time")
	 String pay_time;
	
}
