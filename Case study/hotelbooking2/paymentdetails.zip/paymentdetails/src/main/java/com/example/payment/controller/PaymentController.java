package com.example.payment.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.payment.exception.ResourceNotFoundException;

import com.example.payment.model.Payment;
import com.example.payment.repository.PaymentRepository;

@RestController
@RequestMapping("/hms/v3/")
public class PaymentController {

	@Autowired
	PaymentRepository paymentrepository;
	@GetMapping("/payment")
	public List<Payment> getAllpayment()
	{
	return  paymentrepository.findAll();
	}
	@PostMapping("/payment")
	public Payment createpayment(@RequestBody Payment payment)
	{
		return   paymentrepository.save(payment); 
	}
	
	@PutMapping("/payment/{id}")
	public ResponseEntity<Payment> updateguest(@PathVariable Long id,@RequestBody Payment paymentdetails)
	{
		Payment payment=paymentrepository.findById(id)
		.orElseThrow(() -> new ResourceNotFoundException("Payment not exist with id :" + id));
	     payment.setCard_holder_name(payment.getCard_holder_name());
	     payment.setCard_number(payment.getCard_number());
	     payment.setExp_date(payment.getExp_date());
	     payment.setAmount(payment.getAmount());
	     payment.setPay_time(payment.getPay_time());
		
		
	

		Payment updatedpayment = paymentrepository.save(payment);
		return ResponseEntity.ok(updatedpayment);
		
	}
	@DeleteMapping("/payment/{id}")
	public ResponseEntity<Map<String, Boolean>> deleteEmployee(@PathVariable Long id) {
	Payment payment = paymentrepository.findById(id)
				.orElseThrow(() -> new ResourceNotFoundException("Payment not exist with id :" + id));
paymentrepository.delete(payment);
		Map<String, Boolean> response = new HashMap<>();
		response.put("deleted", Boolean.TRUE);
		return ResponseEntity.ok(response);
	}

	
	
}
