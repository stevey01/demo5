package com.example.staff.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.staff.exception.ResourceNotFoundException;

import com.example.staff.model.Staff;
import com.example.staff.repository.StaffRepository;

@RestController
@RequestMapping("/hms/v2/")
public class StaffController {

	@Autowired
	StaffRepository staffrepository;
	@GetMapping("/staff")
	public List<Staff> getAllstaff()
	{
	return staffrepository.findAll();
	}
	@PostMapping("/staff")
	public Staff createStaff(@RequestBody Staff staff)
	{
		return  staffrepository.save(staff); 
	}
	
	@PutMapping("/staff/{id}")
	public ResponseEntity<Staff> updateguest(@PathVariable Long id,@RequestBody Staff staffdetails)
	{
		Staff staff=staffrepository.findById(id)
		.orElseThrow(() -> new ResourceNotFoundException("Guest not exist with id :" + id));
	     staff.setName(staffdetails.getName());
	     staff.setAddress(staffdetails.getAddress());
	     staff.setSalary(staffdetails.getSalary());
	     staff.setOccupation(staffdetails.getOccupation());
	     staff.setEmail(staffdetails.getEmail());
		
		
	

		Staff updatedStaff = staffrepository.save(staff);
		return ResponseEntity.ok(updatedStaff);
		
	}
	@DeleteMapping("/staff/{id}")
	public ResponseEntity<Map<String, Boolean>> deleteEmployee(@PathVariable Long id) {
	Staff staff = staffrepository.findById(id)
				.orElseThrow(() -> new ResourceNotFoundException("Employee not exist with id :" + id));

		staffrepository.delete(staff);
		Map<String, Boolean> response = new HashMap<>();
		response.put("deleted", Boolean.TRUE);
		return ResponseEntity.ok(response);
	}

	
	
}
