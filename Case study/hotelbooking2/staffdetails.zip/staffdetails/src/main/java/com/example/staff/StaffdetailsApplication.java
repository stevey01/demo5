package com.example.staff;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;



@SpringBootApplication
public class StaffdetailsApplication {

	public static void main(String[] args) {
		SpringApplication.run(StaffdetailsApplication.class, args);
	}

}
