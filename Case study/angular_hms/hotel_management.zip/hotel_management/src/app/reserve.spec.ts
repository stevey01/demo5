import { Reserve } from './reserve';

describe('Reserve', () => {
  it('should create an instance', () => {
    expect(new Reserve()).toBeTruthy();
  });
});
