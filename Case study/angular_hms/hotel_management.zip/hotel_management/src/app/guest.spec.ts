import { Guest } from './guest';

describe('Guest', () => {
  it('should create an instance', () => {
    expect(new Guest()).toBeTruthy();
  });
});
