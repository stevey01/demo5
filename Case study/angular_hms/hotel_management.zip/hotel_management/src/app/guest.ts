export class Guest {


    id!: number;
    phno:number | undefined;
    name:string | undefined;
    gender:string | undefined;
    email:string | undefined;
    company:string | undefined;
    address:string | undefined;
}
