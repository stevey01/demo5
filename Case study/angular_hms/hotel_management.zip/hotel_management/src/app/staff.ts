export class Staff {
	 id!: number;
	 name: string | undefined;	
	 address:string | undefined;
	Salary: number | undefined;
	 Occupation:string | undefined;
	 email:string | undefined;
}
