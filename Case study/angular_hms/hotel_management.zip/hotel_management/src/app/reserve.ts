export class Reserve {

    id!: number;
no_of_Adult:number | undefined;
no_of_child:number | undefined;
check_in_date:String | undefined;
checkout_date:String | undefined;
    Status!: String;
    Number_of_Nights!: number;


}



